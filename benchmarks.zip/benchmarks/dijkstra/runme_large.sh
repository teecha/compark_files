#!/bin/sh
dijkstra_large input.dat > output_large.dat
